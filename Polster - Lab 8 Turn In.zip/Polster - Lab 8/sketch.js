var dino, meteor, explosion, impact = false;

function preload()
{
  dino = loadImage("Isisaurus_in_landscape_700x500.jpg");
  meteor = loadImage("meteor_350x231.png");
  explosion = loadImage("explosion_700x525.jpg");
}

function setup() 
{
  createCanvas(700, 500);
  frameRate(15);
  colorMode(RGB, 255, 255, 255, 1);
}

function draw() 
{
  background(0);
  image(dino, 0, 0);
  if(impact === false)
  {
    image(meteor, mouseX - 100, mouseY - 100);
    textFont('Gotham', 40);
    fill('green');
    stroke('white');
    text("It's so. . . peaceful. Hopefully nothing bad will happen.", 125, 400, 500, 200);
  }
  if(mouseY > 450)
    {
      impact = true;
    }
  if(impact === true)
  {
    noStroke();
    fill(255, 200, 200, .8);
    rect(0, 0, 700, 500);
    image(explosion, 0, 0, mouseX, mouseY);
    textFont('Gotham', 40);
    fill('red');
    stroke('black');
    text(". . . Seriously? I was just saying-", 250, 400, 300, 200);
  }
}