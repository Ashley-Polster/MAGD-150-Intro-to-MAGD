//variable initialization
var x = 0, y = 0, n = 0;

function setup() 
{
  createCanvas(600, 400);
  colorMode(RGB, 255);
  angleMode(RADIANS);
  frameRate(1);
  background(20);
}

function draw() 
{
  //make a loop to display a grid of bees
  for(var r = 0; r <= 3; r++)
  {
    for(var c = 0; c <= 9; c++)
    {
      //move a specific bee from the group to the bottom and rotate
      if(r === 1 && c === 7)
      {
        push();
        rotate(5 * PI / 4);
        bee(-600, 100);
        pop();
      }
      //all the bees in the grid
      else
      {
        bee(55 * c, r * 50); //move bees in relation to first position based on row and column
      }
    }
  }
  n = (r) * (c); // n = 4 * 10
  //say how many bees there are
  print('There are ' + n + ' bees.');
}


function bee(x, y)
{
  push();
  //move bees by the specified amount
  translate(x, y);
  //move all bees
  translate(0, -20);
  //shrink the bees
  scale(.4);
  noStroke();
  
  fill(255, 255, 0); //yellow
  //mouth
  rect(120, 90, 10);
  //head
  rect(100, 100, 50, 30);
  //body
  rect(110, 130, 30, 50);
  
  fill(224, 72, 34); //brown
  //eyes
  rect(110, 100, 10, 20);
  rect(100, 110, 10);
  rect(130, 100, 10, 20);
  rect(140, 110, 10);
  //stripe
  rect(110, 140, 30, 20);
  //stinger
  rect(110, 170, 30, 10);
  rect(120, 180, 10);

  fill(20, 140, 150); //cyan
  //left front wing
  rect(90, 110, 10);
  rect(80, 100, 10);
  rect(70, 90, 10);
  //right front wing
  rect(150, 110, 10);
  rect(160, 100, 10);
  rect(170, 90, 10);
  //back left wing
  rect(90, 130, 20);
  rect(80, 140, 20, 30);
  rect(70, 150, 20);
  rect(60, 160, 30);
  //back right wing
  rect(140, 130, 20);
  rect(150, 140, 20, 30);
  rect(160, 150, 20);
  rect(160, 160, 30);
  pop();
}