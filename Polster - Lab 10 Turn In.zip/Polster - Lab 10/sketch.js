let top_board, bottom_board, left_cup, right_cup, middle_cup, ball1, ball2, ball3;

function setup() 
{
  new Canvas(500, 500);
  print('I used p5play by Quinton Ashley and Paolo Pedercini. It focuses on creating sprites and checking for collisions and applying forces to the sprites such as gravity. It is also meant to make animations easier. It essentially applies physics to 2D objects. It also has many other miscellaneous features, such as zooming and sound. I used it to create sprites that have different collider types, to create global gravity, and to change the velocity of the dynamic sprites based on arrow inputs.');
  
  world.gravity.y = 0.5;
  let top_board = new Sprite([ [10, 300], [10, 10], [490, 10], [490, 300]], 'static');
  let bottom_board = new Sprite([ [490, 300], [250, 450], [10, 300]], 'static');
  
  //left
  let x = 100;
  let y = 130;
  let left_cup = new Sprite ([ [x, y], [x, y + 40], [x + 60, y + 40], [x + 60, y]], 'static');
  
  //right
  x = 340;
  let right_cup = new Sprite ([ [x, y], [x, y + 40], [x + 60, y + 40], [x + 60, y]], 'static');
  
  //middle
  x = 220;
  y = 300;
  let middle_cup = new Sprite([ [x, y], [x, y + 40], [x + 60, y + 40], [x + 60, y]], 'static');
  
  //balls
  x = 150;
  y = 250;
  let d = 30
  ball1 = new Sprite(x, y, d);
  x += 100;
  ball2 = new Sprite(x, y, d);
  x += 100;
  ball3 = new Sprite(x, y, d);
  
}

function draw() {
  clear();

  //controls
  if(kb.presses('left'))
    {
      ball1.vel.x += -1;
      ball2.vel.x += -1;
      ball3.vel.x += -1;
    }
  if(kb.presses('right'))
    {
      ball1.vel.x += 1;
      ball2.vel.x += 1;
      ball3.vel.x += 1;
    }
  if(kb.presses('up'))
    {
      ball1.vel.y += -1;
      ball2.vel.y += -1;
      ball3.vel.y += -1;
    }
  if(kb.presses('down'))
    {
      ball1.vel.y += 1;
      ball2.vel.y += 1;
      ball3.vel.y += 1;
    }
}