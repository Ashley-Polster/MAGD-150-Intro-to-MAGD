function setup() 
{
  createCanvas(1000, 1000);
  background(240);
  colorMode(RGB, 255, 255, 255, 1);
}

function draw() 
{
  balloon (800, -200, 0, 200, 200); // light blue
  balloon (50, 120, 0, 50, 150); // dark blue
  balloon (-300, -100, 250, 100, 0); //orange
  
  balloon (-250, 250, 140, 0, 200); //purple
  balloon (-60, 120, 250, 250, 0); //yellow
  
  balloon (300, 180, 250, 20, 20); //red
  balloon (200, -90, 50, 180, 50); //green
}  
 
function balloon (x, y, r, g, b) 
{
  translate (x, y)
  noStroke();
  fill(r, g, b, .2);
  bezier(100, 370, 30, 320, 30, 300, 40, 250);
  bezier(40, 250, 50, 220, 70, 205, 100, 200);
  bezier(100, 370, 170, 320, 170, 300, 160, 250);
  bezier(160, 250, 150, 220, 130, 205, 100, 200);
  quad(40, 251, 100, 200, 160, 251, 100, 370)
  triangle(95, 375, 100, 360, 105, 375);
  ellipse(100, 375, 15, 5);
  stroke(200, 200, 200, .5);
  strokeWeight(7);
  noFill();
  curve(100, 300, 100, 370, 50, 700, 250, 800);
}