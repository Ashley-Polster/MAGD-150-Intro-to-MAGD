let value = 0;
function setup() 
{
  createCanvas(400, 400);
  colorMode(RGB, 255);
  frameRate(1);
}

function draw() 
{
  background(255);
 
//border
  stroke(0);
  border(0, 60);
  border(340, 400);

//instructions and word setup
  textSize(30);
  text("Finish the word", 20, 100);
  textSize(200);
  text("b   g", 0, 290);

//changes text to purple and darkens underscore line when pressed  
    if(keyIsPressed === true)
    {
      stroke(0);
      fill(100, 0, 255);
    }
    else
    {
      stroke(200);
      fill(0);
    }
//the line for user input
  line(120, 300, 260, 300);  
  text(key, 150, 290);
}

//makes the border
function border(w, x)
{
    for(let i = -100; i < 500; i += 50)
    {
      line(i, w, i + 130, x);
    }
}

//turns the text red once the mouse is pressed
function mousePressed()
{
  if(value === 0)
  {
    fill(255, 0, 0);
  }
  else
  {
    fill(0);
  } 
}