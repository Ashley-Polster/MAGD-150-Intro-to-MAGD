function setup() 
{
 createCanvas(400,400);
  background(30);
}

function draw() 
{
  strokeJoin(ROUND);
  strokeWeight(3);
  //road and sidewalk
  line(210, 400, 310, 0)
  line(250, 400, 350, 0)
  line(260, 400, 360, 0)
  
  //building far
  fill(50);
  rect(70, 100, 170, 90) //face
  noFill();
  quad(70, 100, 95, 0, 265, 0, 240, 100); //top
  fill(50);
  quad(240, 190, 240, 100, 265, 0, 287.5, 0); //roadside
  
  //building middle
  fill(60);
  rect(30, 230, 200, 50) //face
  quad(30, 230, 50, 150, 250, 150, 230, 230); //top
  quad(230, 280, 230, 230, 250, 150, 250, 200); //roadside
  
  //building close
  noFill();
  rect(50, 300, 150, 100) ///face
  fill(70);
  quad(50, 300, 70, 220, 220, 220, 200, 300); //top
  quad(200, 400, 200, 300, 220, 220, 220, 320); //roadside  
}