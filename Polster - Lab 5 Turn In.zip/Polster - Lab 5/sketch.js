//variable initialization
var power_btn_origin_x = 300;
var power_btn_origin_y = 355;
var channel_btn_origin_x = 500;
var channel_btn_origin_y = 355;
var power_on = false;
var channel_number = 0;
var screen_transparency = 0;

function setup() 
{
  createCanvas(600, 400);
  colorMode(RGB, 255, 255, 255, 1);
}

function draw() {
  background(0);
  
  //TV frame
  stroke(100);
  strokeWeight(100);
  noFill();
  rect(0, 0, 600, 360);
  
  //power button (middle)
  stroke(220);
  strokeWeight(5);
  fill(0);
  ellipseMode(CENTER); 
  ellipse(300, 355, 60);
    //the "P"
  fill(255, 0, 0);
  strokeWeight(2);
  stroke(255, 0, 0)
  textSize(30);
  textAlign(CENTER);
  text('P', 300, 365);

  //channel button (left)
  stroke(220);
  strokeWeight(5);
  fill(0);
  beginShape(QUAD_STRIP);
  vertex(60, 330);
  vertex(60, 380);
  vertex(100, 330);
  vertex(100, 380);
  vertex(140, 330);
  vertex(140, 380);
  endShape();
  line(100, 330, 60, 355);
  line(100, 380, 60, 355);
  line(100, 330, 140, 355);
  line(100, 380, 140, 355);

  //brightness button (right)
  ellipse(500, 355, 60);
  line(470, 355, 530, 355);
  line(480, 350, 500, 330);
  line(520, 350, 500, 330);
  line(480, 360, 500, 380);
  line(520, 360, 500, 380);
    
  //set screen color based on channel number
  if(channel_number === 0)
  {
    fill(11, 78, 230, screen_transparency); //dark blue
  }
  else if(channel_number === 1)
  {
    fill(0, 189, 229, screen_transparency); //light blue
  }
  else if(channel_number === 2)
  {
    fill(11, 230, 145, screen_transparency); //mint
  }
  else if(channel_number === 3)
  {
    fill(230, 168, 23, screen_transparency); //yellow
  }
  else if(channel_number === 4)
  {
    fill(230, 58, 23, screen_transparency); //orange
  }
  
  //the screen. color is controlled by the channel number, brightness by the screen transparency (because the background is black, so the more transparent the screen, the darker it is)
  noStroke();
  quad(50, 50, 550, 50, 550, 310, 50, 310); 
}

function keyPressed()
{  
  //power button activation. mouse must be over the button and press 'p'
  if(dist(mouseX, mouseY, power_btn_origin_x, power_btn_origin_y) <= 60)
  {
    if(key === 'p' && power_on === false)
    {
      power_on = true;
      key = ' '; //reset the key
      screen_transparency += 1;
    }
    if(key === 'p' && power_on === true)
    {
      power_on = false;
      key = ' '; //reset the key
      screen_transparency -= 1;
    }
  }
}

function mousePressed()
{
  if(power_on === true) //only allow channel and brightness changes if the power is on
  {
    //channel button activation. mouse must click one side of the button.
    if(mouseX > 60 && mouseX < 140 && mouseY > 330 && mouseY < 380)
    {
      if(mouseX < 100) //left arrow, decrease channel number
      {
        channel_number--;
        //cycle the channel number to the end if you get to the beginning
        if(channel_number === -1)
        {
          channel_number = 4;
        }
      }
      if(mouseX > 100) //right arrow, increase channel number
      {
        channel_number++;
        //cycle the channel number to the start if you get to the end
        if(channel_number === 5)
        {
          channel_number = 0;
        }
      }
    }
    //brightness button activation. mouse must click one side of the button.
    if(dist(mouseX, mouseY, channel_btn_origin_x, channel_btn_origin_y) <= 60) 
    {
      if(mouseY < 355) //up arrow, increase brightness by increasing transparency value
      {
        if(screen_transparency < 1)
        {
          screen_transparency += 0.1; //increase brightness
        }
      }
      if(mouseY > 355) //down arrow, decrease brightness by decreasing transparency value
      {
        if(screen_transparency > 0.6)
        {
          screen_transparency -= 0.1; //decrease brightness
        }
      }
    }
  }
}