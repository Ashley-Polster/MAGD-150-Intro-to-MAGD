let fr = 0;
let d = 0;
let mx = 0;
let my = 0;

function setup() 
{
  createCanvas(500, 500);
  background(200);
  colorMode(RGB, 255, 255, 255, 1);
  let fr = sqrt(2);
  frameRate(fr);
  
}

function draw() 
{
  
  let d = dist(mouseX, mouseY, pmouseX, pmouseY);
  paw(-50, -d/3);
  paw(50, d/3);
  

}

function paw(x, y)
{
  let mx = mouseX;
  let my = mouseY;
  noStroke();
  //paw pad
  fill(250, 0, 150, .1);
  ellipse(mx + x, my + y, 20, 30);
  //toe pads
  fill(250, 0, 0, .1)
  ellipse(mx + x - 17, my + y - 12, 10, 20);
  ellipse(mx + x - 7, my + y - 25, 10, 20);
  ellipse(mx + x + 7, my + y - 25, 10, 20);
  ellipse(mx + x + 17, my + y - 12, 10, 20);  
  //paw imprint
  fill(50, 0, 25, .1)
  ellipse(mx + x, my + y - 10, 45, 60);
}