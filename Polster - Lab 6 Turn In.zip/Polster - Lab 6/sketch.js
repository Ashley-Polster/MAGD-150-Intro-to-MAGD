//declare variables
var i;
var x_trans = [];
var y_trans = [];
var r_rotate = [];

function setup() 
{
  createCanvas(1000, 500);
  //create values for 500 leaves
  //set the x position
  for(i = 0; i < 500; i++)
  {
    x_trans[i] = random(-500, 1000);
  }
  //set the y position
  for(i = 0; i < 500; i++)
  {
    y_trans[i] = random(-2000, -100);
  }
  //set the rotate value
  for(i = 0; i < 500; i++)
  {
    r_rotate[i] = random(0, 2);
  }
  //print the length of all arrays
  print(x_trans.length); //prints length of array x
  print(y_trans.length); //prints length of array x
  print(r_rotate.length); //prints length of array x
}

function draw() 
{
  background(220);
  //create each leaf based on the created arrays
  for(i = 0; i < 500; i++)
  {
    push();
    leaf(x_trans[i], y_trans[i], r_rotate[i]);
    pop();
  }
  //update the position of the leaves based on mouse position and update rotation based on mouse movement. represents the wind.
  for(i = 0; i < 500; i++)
  {
    x_trans[i] += mouseX * 0.001;
    y_trans[i] += mouseY * 0.005;
    r_rotate[i] += (pmouseX + pmouseY) * 0.000001;
  }
}

//create the base for each leaf and set how the variables influence the leaves
function leaf(x, y, r)
{
  fill('orange');
  noStroke();
  translate(-100, -100);
  translate(x, y);
  rotate(PI * r)
  scale(0.2);
  beginShape();
    vertex(200, 20); //top middle
    vertex(170, 100);
    vertex(130, 70);
    vertex(140, 190);
    vertex(100, 120);
    vertex(90, 150);
    vertex(30, 120);
    vertex(50, 180);
    vertex(10, 180);
    vertex(130, 300);
    vertex(110, 330);
    vertex(190, 320);
    vertex(185, 390);
    vertex(200, 385); //bottom middle
    vertex(215, 390);
    vertex(210, 320);
    vertex(290, 330);
    vertex(270, 300);
    vertex(390, 180);
    vertex(350, 180);
    vertex(370, 120);
    vertex(310, 150);
    vertex(300, 120);
    vertex(260, 190);
    vertex(270, 70);
    vertex(230, 100);
    vertex(200, 20); //top middle
  endShape();  
}